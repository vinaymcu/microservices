
package com.acn.avs.push.messaging.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "MulticastMessageFilters"
})
public class MulticastMessageFilters implements Serializable
{

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("MulticastMessageFilters")
    private List<MulticastMessageFilter> multicastMessageFilters = new ArrayList<MulticastMessageFilter>();
    private final static long serialVersionUID = 7244524925877417532L;

    /**
     * 
     * (Required)
     * 
     * @return
     *     The multicastMessageFilters
     */
    @JsonProperty("MulticastMessageFilters")
    public List<MulticastMessageFilter> getMulticastMessageFilters() {
        return multicastMessageFilters;
    }

    /**
     * 
     * (Required)
     * 
     * @param multicastMessageFilters
     *     The MulticastMessageFilters
     */
    @JsonProperty("MulticastMessageFilters")
    public void setMulticastMessageFilters(List<MulticastMessageFilter> multicastMessageFilters) {
        this.multicastMessageFilters = multicastMessageFilters;
    }

    public MulticastMessageFilters withMulticastMessageFilters(List<MulticastMessageFilter> multicastMessageFilters) {
        this.multicastMessageFilters = multicastMessageFilters;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(multicastMessageFilters).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MulticastMessageFilters) == false) {
            return false;
        }
        MulticastMessageFilters rhs = ((MulticastMessageFilters) other);
        return new EqualsBuilder().append(multicastMessageFilters, rhs.multicastMessageFilters).isEquals();
    }

}
