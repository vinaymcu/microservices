
package com.acn.avs.push.messaging.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "MessageDetails"
})
public class GetMessagesResponse implements Serializable
{

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("MessageDetails")
    private List<MessageDetail> messageDetails = new ArrayList<MessageDetail>();
    private final static long serialVersionUID = -517107366493353940L;

    /**
     * 
     * (Required)
     * 
     * @return
     *     The messageDetails
     */
    @JsonProperty("MessageDetails")
    public List<MessageDetail> getMessageDetails() {
        return messageDetails;
    }

    /**
     * 
     * (Required)
     * 
     * @param messageDetails
     *     The MessageDetails
     */
    @JsonProperty("MessageDetails")
    public void setMessageDetails(List<MessageDetail> messageDetails) {
        this.messageDetails = messageDetails;
    }

    public GetMessagesResponse withMessageDetails(List<MessageDetail> messageDetails) {
        this.messageDetails = messageDetails;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(messageDetails).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof GetMessagesResponse) == false) {
            return false;
        }
        GetMessagesResponse rhs = ((GetMessagesResponse) other);
        return new EqualsBuilder().append(messageDetails, rhs.messageDetails).isEquals();
    }

}
