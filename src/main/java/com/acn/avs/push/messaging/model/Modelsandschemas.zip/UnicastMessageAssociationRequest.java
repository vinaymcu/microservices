
package com.acn.avs.push.messaging.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "UnicastMessageAssociation"
})
public class UnicastMessageAssociationRequest implements Serializable
{

    @JsonProperty("UnicastMessageAssociation")
    private List<UnicastMessageAssociation> unicastMessageAssociation = new ArrayList<UnicastMessageAssociation>();
    private final static long serialVersionUID = 8665594979300883224L;

    /**
     * 
     * @return
     *     The unicastMessageAssociation
     */
    @JsonProperty("UnicastMessageAssociation")
    public List<UnicastMessageAssociation> getUnicastMessageAssociation() {
        return unicastMessageAssociation;
    }

    /**
     * 
     * @param unicastMessageAssociation
     *     The UnicastMessageAssociation
     */
    @JsonProperty("UnicastMessageAssociation")
    public void setUnicastMessageAssociation(List<UnicastMessageAssociation> unicastMessageAssociation) {
        this.unicastMessageAssociation = unicastMessageAssociation;
    }

    public UnicastMessageAssociationRequest withUnicastMessageAssociation(List<UnicastMessageAssociation> unicastMessageAssociation) {
        this.unicastMessageAssociation = unicastMessageAssociation;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(unicastMessageAssociation).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UnicastMessageAssociationRequest) == false) {
            return false;
        }
        UnicastMessageAssociationRequest rhs = ((UnicastMessageAssociationRequest) other);
        return new EqualsBuilder().append(unicastMessageAssociation, rhs.unicastMessageAssociation).isEquals();
    }

}
